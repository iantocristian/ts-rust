package testrunner

import (
	"bytes"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"runtime"
	"slices"
	"strings"
	"testing"

	"github.com/microsoft/TypeScript/tsc/internal/ast"
	"github.com/microsoft/TypeScript/tsc/internal/core"
	"github.com/microsoft/TypeScript/tsc/internal/diagnosticwriter"
	"github.com/microsoft/TypeScript/tsc/internal/repo"
	"github.com/microsoft/TypeScript/tsc/internal/testutil/baseline"
	"github.com/microsoft/TypeScript/tsc/internal/testutil/harnessutil"
	"github.com/microsoft/TypeScript/tsc/internal/testutil/tsbaseline"
	"github.com/microsoft/TypeScript/tsc/internal/tspath"
	"github.com/microsoft/TypeScript/tsc/internal/vfs/osvfs"
)

type s08Request struct {
	ID                string            `json:"id"`
	Path              string            `json:"path"`
	RawSHA256         string            `json:"raw_sha256"`
	LoadedSHA256      string            `json:"loaded_sha256"`
	Settings          map[string]string `json:"settings"`
	ConfigurationName string            `json:"configuration_name"`
	ConfiguredName    string            `json:"configured_name"`
	AcceptanceTier    string            `json:"acceptance_tier"`
}

func s08Hash(raw []byte) string { value := sha256.Sum256(raw); return hex.EncodeToString(value[:]) }

func s08Failure(row map[string]any, reason, message string) {
	stage := row["execution_stage"].(string)
	state := "harness_failed"
	if strings.HasPrefix(stage, "native_") {
		state = "upstream_failed"
		if reason == "panic" || reason == "assertion" {
			reason = "native_" + reason
		}
	}
	row["state"] = state
	row["failure"] = map[string]string{"stage": stage, "reason": reason, "message": message}
}

func s08Diagnostics(values []*ast.Diagnostic) []map[string]any {
	result := make([]map[string]any, 0, len(values))
	for _, d := range values {
		var file any
		if d.File() != nil {
			file = d.File().FileName()
		}
		result = append(result, map[string]any{
			"file": file, "pos": d.Pos(), "end": d.End(), "code": d.Code(), "category": d.Category(),
			"key_hex": hex.EncodeToString([]byte(d.MessageKey())), "text_hex": hex.EncodeToString([]byte(d.MessageText())),
			"source_hex": hex.EncodeToString([]byte(d.Source())), "args": d.MessageArgs(),
			"chain": s08Diagnostics(d.MessageChain()), "related": s08Diagnostics(d.RelatedInformation()),
			"unnecessary": d.ReportsUnnecessary(), "deprecated": d.ReportsDeprecated(), "skipped_on_no_emit": d.SkippedOnNoEmit(),
		})
	}
	return result
}

func TestS08Baselines(t *testing.T) {
	// Empty content is an observed file, distinct from the source's NoContent
	// sentinel and a baseline disabled by harness policy. Preserve arbitrary bytes.
	for _, fixture := range []struct{ value, expected string }{
		{"", `{"state":"content","text_hex":""}`},
		{baseline.NoContent, `{"state":"no_content"}`},
		{"\xff", `{"state":"content","text_hex":"ff"}`},
	} {
		encoded, err := json.Marshal(tsbaseline.S08BaselineValue(fixture.value))
		if err != nil || string(encoded) != fixture.expected {
			t.Fatalf("baseline outcome contract: %q, %v", encoded, err)
		}
	}
	raw, err := os.ReadFile(os.Getenv("S08_REQUESTS"))
	if err != nil {
		t.Fatal(err)
	}
	decoder := json.NewDecoder(bytes.NewReader(raw))
	decoder.DisallowUnknownFields()
	var requests []s08Request
	if err := decoder.Decode(&requests); err != nil {
		t.Fatal(err)
	}
	var extra any
	if err := decoder.Decode(&extra); err != io.EOF {
		t.Fatalf("trailing input: %v", err)
	}
	seen := map[string]bool{}
	for _, request := range requests {
		if request.ID == "" || seen[request.ID] || (request.AcceptanceTier != "acceptance" && request.AcceptanceTier != "informational") {
			t.Fatal("empty/duplicate request")
		}
		seen[request.ID] = true
	}
	output, err := os.Create(os.Getenv("S08_OUTPUT"))
	if err != nil {
		t.Fatal(err)
	}
	defer output.Close()
	encoder := json.NewEncoder(output)
	for _, request := range requests {
		tsbaseline.S08CollectTypeStrings = true
		row := map[string]any{"id": request.ID, "acceptance_tier": request.AcceptanceTier, "state": "not_executed", "execution_stage": "harness_input", "queries": []tsbaseline.S08Query{}}
		complete := false
		t.Run(request.ID, func(t *testing.T) {
			defer func() {
				if value := recover(); value != nil {
					row["panic"] = fmt.Sprint(value)
					s08Failure(row, "panic", fmt.Sprint(value))
					t.Error("baseline panic", value)
				}
				if t.Failed() {
					if row["failure"] == nil {
						s08Failure(row, "assertion", "test assertion failed; see go.stdout")
					}
				} else if !complete {
					if t.Skipped() && row["execution_stage"] == "native_option_guard" {
						row["state"] = "upstream_skipped"
					} else {
						row["execution_stage"] = "harness_incomplete"
						s08Failure(row, "incomplete", "baseline execution exited before completion")
					}
				}
				harnessutil.S08ObserveDiagnostics = nil
				harnessutil.S08ObserveStage = nil
				harnessutil.S08ObserveOptionRejection = nil
				tsbaseline.S08Queries = nil
			}()
			stage := func(next string) func() {
				previous := row["execution_stage"]
				if t.Failed() && row["failure"] == nil {
					s08Failure(row, "assertion", "test assertion failed; see go.stdout")
				}
				row["execution_stage"] = next
				return func() { row["execution_stage"] = previous }
			}
			fail := func(reason string, values ...any) {
				s08Failure(row, reason, fmt.Sprint(values...))
				t.Fatal(values...)
			}
			harnessutil.S08ObserveStage = stage
			harnessutil.S08ObserveOptionRejection = func(message string) {
				s08Failure(row, "option_rejected", message)
			}
			path := filepath.Join(repo.RootPath(), strings.TrimPrefix(request.Path, "tsc/"))
			original, err := os.ReadFile(path)
			if err != nil {
				fail("source_read", err)
			}
			if s08Hash(original) != request.RawSHA256 {
				fail("source_digest", "physical source digest differs")
			}
			loaded, ok := osvfs.FS().ReadFile(path)
			if !ok || s08Hash([]byte(loaded)) != request.LoadedSHA256 {
				fail("source_digest", "loaded source digest differs")
			}
			row["raw_sha256"] = s08Hash(original)
			row["loaded_sha256"] = s08Hash([]byte(loaded))
			row["native_runner_skipped"] = slices.Contains(skippedTests, tspath.GetBaseFileName(path))
			harnessutil.S08ObserveDiagnostics = func(pre, post []*ast.Diagnostic) {
				restore := harnessutil.S08EnterObservation()
				row["pre_diagnostics"] = s08Diagnostics(pre)
row["error_pre_diagnostics"] = s08ErrorDiagnostics(pre)
				row["post_diagnostics"] = s08Diagnostics(post)
row["error_post_diagnostics"] = s08ErrorDiagnostics(post)
				restore()
			}
			stage("native_parse")
			payload := makeUnitsFromTest(loaded, path)
			configuration := &harnessutil.NamedTestConfiguration{Config: request.Settings, Name: request.ConfigurationName}
			stage("native_setup")
			c := newCompilerTest(t, request.ID, path, &payload, configuration)
			stage("harness_identity")
			if c.configuredName != request.ConfiguredName {
				fail("configured_name", "configured name drift", c.configuredName)
			}
			row["options"] = c.options
			row["harness_options"] = c.harnessOptions
			if request.AcceptanceTier != "informational" || os.Getenv("S08_INCLUDE_INFORMATIONAL") != "1" {
				stage("native_option_guard")
				harnessutil.SkipUnsupportedCompilerOptions(t, c.options)
			}
			stage("harness_observation")
			files := make([]map[string]any, 0)
			for _, f := range c.result.Program.GetSourceFiles() {
				files = append(files, map[string]any{"name": f.FileName(), "path": string(f.Path()), "sha256": s08Hash([]byte(f.Text())), "bytes": len(f.Text())})
			}
			row["files"] = files
			row["diagnostics"] = s08Diagnostics(c.result.Diagnostics)

            errorInputs := core.Concatenate(c.tsConfigFiles, core.Concatenate(c.toBeCompiled, c.otherFiles))
            observeInputs := func(files []*harnessutil.TestFile) []map[string]string {
                inputs := []map[string]string{}
                for _, f := range files { inputs = append(inputs, map[string]string{"name_hex":hex.EncodeToString([]byte(f.UnitName)), "content_hex":hex.EncodeToString([]byte(f.Content))}) }
                return inputs
            }
            row["error_inputs"] = observeInputs(errorInputs)
            row["error_pretty"] = c.options.Pretty.IsTrue()
            row["errors"] = func() tsbaseline.S08Baseline {
		files := core.Concatenate(c.tsConfigFiles, core.Concatenate(c.toBeCompiled, c.otherFiles))
		diagnostics := c.result.Diagnostics
		// Content-mapped files' diagnostics are baselined separately (see verifyContentMapper), where they can
		// be rendered against the correct text; the squiggle renderer here assumes a single coordinate space.
		if contentMapped := c.contentMappedFileNames(); len(contentMapped) > 0 {
			files = core.Filter(files, func(f *harnessutil.TestFile) bool {
				return !contentMapped[tspath.GetNormalizedAbsolutePath(f.UnitName, c.currentDirectory)]
			})
			diagnostics = core.Filter(diagnostics, func(d *ast.Diagnostic) bool {
				return d.File() == nil || !contentMapped[d.File().FileName()]
			})
		}

                row["error_render_inputs"] = observeInputs(files)
                row["error_diagnostics"] = s08ErrorDiagnostics(diagnostics)
                if len(diagnostics) == 0 { return tsbaseline.S08BaselineValue(baseline.NoContent) }
                stage("native_error_baseline")
                value := tsbaseline.GetErrorBaseline(t, files, diagnosticwriter.WrapASTDiagnostics(diagnostics), diagnosticwriter.CompareASTDiagnostics, c.options.Pretty.IsTrue())
                stage("harness_observation")
                return tsbaseline.S08BaselineValue(value)
            }()
			for _, d := range c.result.Diagnostics {
				if d.Code() == -1 {
					stage("native_error_baseline")
					t.Fatal("source diagnostic assertion (-1)")
				}
			}
			row["types"] = tsbaseline.S08Baseline{State: "disabled"}
			row["symbols"] = tsbaseline.S08Baseline{State: "disabled"}
			if !c.harnessOptions.NoTypesAndSymbols {
				allFiles := core.Filter(core.Concatenate(c.toBeCompiled, c.otherFiles), func(f *harnessutil.TestFile) bool { return c.result.Program.GetSourceFile(f.UnitName) != nil })
				header := tspath.GetPathFromPathComponents(tspath.GetPathComponentsRelativeTo(repo.TestDataPath(), path, tspath.ComparePathsOptions{}))
				inputs := []map[string]string{}
				for _, f := range allFiles { inputs = append(inputs, map[string]string{"name_hex":hex.EncodeToString([]byte(f.UnitName)), "content_hex":hex.EncodeToString([]byte(f.Content))}) }
				row["baseline_inputs"] = inputs
				row["baseline_header"] = header
				tsbaseline.S08Queries = []tsbaseline.S08Query{}
				stage("native_type_symbol")
				row["types"], row["symbols"] = tsbaseline.S08TypeSymbolBaselines(c.result.Program, allFiles, header, len(c.result.Diagnostics) > 0)
				stage("harness_observation")
				row["queries"] = tsbaseline.S08Queries
				row["public_type_strings"] = map[string]any{"state":"executed", "queries":tsbaseline.S08TypeStrings}
			}
			if t.Failed() {
				// Preserve the stage of a nonfatal native assertion even if the
				// source returned and later observation steps completed.
				row["execution_stage"] = row["failure"].(map[string]string)["stage"]
				return
			}
			stage("complete")
			row["state"] = "executed"
			complete = true
		})
		if err := encoder.Encode(row); err != nil {
			t.Fatal(err)
		}
	}
	summary, err := json.Marshal(map[string]any{"request_sha256": s08Hash(raw), "rows": len(requests), "go": runtime.Version(), "goos": runtime.GOOS, "goarch": runtime.GOARCH})
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(os.Getenv("S08_SUMMARY"), summary, 0600); err != nil {
		t.Fatal(err)
	}
}

// Error comparison preserves bytes before JSON's invalid-UTF8 replacement.
func s08ErrorDiagnostics(values []*ast.Diagnostic) []map[string]any {
    result := s08Diagnostics(values)
    for i, d := range values {
        row := result[i]
        var file any
        if d.File() != nil { file = hex.EncodeToString([]byte(d.File().FileName())) }
        args := []string{}
        for _, arg := range d.MessageArgs() { args = append(args, hex.EncodeToString([]byte(arg))) }
        delete(row, "file"); delete(row, "args")
        row["file_hex"] = file; row["args_hex"] = args
        row["chain"] = s08ErrorDiagnostics(d.MessageChain())
        row["related"] = s08ErrorDiagnostics(d.RelatedInformation())
    }
    return result
}
