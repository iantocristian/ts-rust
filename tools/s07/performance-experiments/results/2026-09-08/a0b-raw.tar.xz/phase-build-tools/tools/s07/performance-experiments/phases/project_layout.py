#!/usr/bin/env python3
"""Project typed page/directory policies from the measured per-file core census.

All sizes are requested payload sizes. This executes arithmetic, not replacement
storage, allocation profiling or acceptance. Full-range escapes remain unknown.
"""
import argparse
from collections import Counter
from functools import lru_cache
import gzip
import json
from pathlib import Path
from statistics import median
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
sys.path.insert(0, str(HERE))
import probe
from s04_common import strict_json_loads

POLICIES = [(1, 32), (1, 64), (1, 128), (2, 32), (2, 64), (2, 128), (2, 256), (4, 32), (4, 64)]
STRATEGIES = ("fixed_vec", "optional_box_vec", "packed_u16_index", "optional_one_or_many", "optional_inline_first")


@lru_cache(None)
def page_plan(count, first, limit):
    if count < 0 or first < 1 or limit < first or first & (first - 1) or limit & (limit - 1):
        raise ValueError("page policy needs nonnegative count and power-of-two bounds")
    capacity, pages, size = 0, 0, first
    while count > capacity and size < limit:
        capacity += size
        pages += 1
        size *= 2
    if count > capacity:
        extra = (count - capacity + limit - 1) // limit
        capacity += extra * limit
        pages += extra
    return capacity, pages


@lru_cache(None)
def vector_plan(count, element_size, first=4):
    if count < 0 or element_size < 0 or first < 1:
        raise ValueError("invalid directory vector inputs")
    if not count:
        return (0, 0, 0)
    capacity, requests, allocations = first, first * element_size, 1
    while capacity < count:
        capacity *= 2
        requests += capacity * element_size
        allocations += 1
    return capacity * element_size, requests, allocations


def compile_directory_sketch(output):
    output.mkdir(parents=True, exist_ok=True)
    executable = output / "directory-sketch"
    source = HERE / "directory_sketch.rs"
    subprocess.run(["rustc", "--edition=2021", "-Dwarnings", str(source), "-o", str(executable)], check=True)
    version = subprocess.run(["rustc", "-vV"], capture_output=True, text=True, check=True).stdout
    raw = subprocess.run([str(executable)], capture_output=True, text=True, check=True).stdout
    return ({name: {"size": int(size), "alignment": int(align)} for name, size, align in map(str.split, raw.splitlines())},
            {"rustc": version, "source_sha256": probe.runner.digest(source), "binary_sha256": probe.runner.digest(executable)})


def page_costs(rows, shapes, first, limit, sizes):
    result = {"used_syntax": 0, "used_bound": 0, "capacity_syntax": 0, "capacity_bound": 0,
              "payload_pages": 0, "active_shapes": 0, "one_page_shapes": 0,
              "directory_vec_live": 0, "directory_vec_requests": 0, "directory_vec_allocations": 0,
              "many_directory_live": 0, "many_directory_requests": 0, "many_directory_allocations": 0,
              "tail_directory_live": 0, "tail_directory_requests": 0, "tail_directory_allocations": 0}
    active_per_file = []
    for row in rows:
        active = 0
        for name, count in row["core_shapes"].items():
            syntax, bound = shapes[name]["syntax_layout"]["size"], shapes[name]["bound_layout"]["size"]
            if not bound:
                continue
            active += 1
            capacity, pages = page_plan(count, first, limit)
            result["used_syntax"] += count * syntax
            result["used_bound"] += count * bound
            result["capacity_syntax"] += capacity * syntax
            result["capacity_bound"] += capacity * bound
            result["payload_pages"] += pages
            result["one_page_shapes"] += pages == 1
            for label, length, initial in [("directory_vec", pages, 4),
                                            ("many_directory", pages if pages > 1 else 0, 2),
                                            ("tail_directory", pages - 1, 1)]:
                live, requests, allocations = vector_plan(length, sizes["Page"]["size"], initial)
                result[label + "_live"] += live
                result[label + "_requests"] += requests
                result[label + "_allocations"] += allocations
        active_per_file.append(active)
    result["active_shapes"] = sum(active_per_file)
    return result, active_per_file


def directory_costs(strategy, costs, active_per_file, sizes):
    files, active = len(active_per_file), costs["active_shapes"]
    if strategy == "fixed_vec":
        root, storage, label, boxes = files * sizes["FixedDirectory"]["size"], 0, "directory_vec", 0
    elif strategy == "optional_box_vec":
        root = files * sizes["OptionalDirectory"]["size"]
        storage, label, boxes = active * sizes["VecHeader"]["size"], "directory_vec", active
    elif strategy == "packed_u16_index":
        root, storage, label, boxes = files * sizes["PackedDirectory"]["size"], 0, "directory_vec", 0
        allocations = [vector_plan(count, sizes["PackedPages"]["size"], 1) for count in active_per_file]
        storage = sum(item[0] for item in allocations)
        requests = sum(item[1] for item in allocations)
        return {"live": root + storage + costs[label + "_live"],
                "requests": root + requests + costs[label + "_requests"],
                "shape_roots": root, "shape_storage": storage,
                "page_directories": costs[label + "_live"],
                "allocations_excluding_embedded_root": sum(item[2] for item in allocations) + costs[label + "_allocations"]}
    elif strategy == "optional_one_or_many":
        root = files * sizes["OptionalDirectory"]["size"]
        storage, label, boxes = active * sizes["OneOrMany"]["size"], "many_directory", active
    elif strategy == "optional_inline_first":
        root = files * sizes["OptionalDirectory"]["size"]
        storage, label, boxes = active * sizes["InlineFirst"]["size"], "tail_directory", active
    else:
        raise ValueError("unknown directory policy")
    return {"live": root + storage + costs[label + "_live"],
            "requests": root + storage + costs[label + "_requests"],
            "shape_roots": root, "shape_storage": storage, "page_directories": costs[label + "_live"],
            "allocations_excluding_embedded_root": boxes + costs[label + "_allocations"]}


def header_costs(rows, header_size, first, limit, sizes):
    result = {"used": 0, "capacity": 0, "page_slots": 0, "pages": 0, "directory_live": 0,
              "directory_requests": 0, "directory_allocations": 0}
    for row in rows:
        count = sum(row["core_shapes"].values())
        capacity, pages = page_plan(count, first, limit)
        live, requests, allocations = vector_plan(pages, sizes["Page"]["size"])
        result["used"] += count * header_size
        result["capacity"] += capacity * header_size
        result["page_slots"] += capacity
        result["pages"] += pages
        result["directory_live"] += live
        result["directory_requests"] += requests
        result["directory_allocations"] += allocations
    root = len(rows) * sizes["VecHeader"]["size"]
    result["directory_live"] += root
    result["directory_requests"] += root
    return result


def project(rows, model, sizes):
    shapes = model["shape_inventory"]
    total = Counter()
    for row in rows:
        total.update(row["core_shapes"])
    if set(total) - set(shapes):
        raise ValueError("shape census contains an unknown layout")
    if sizes["FixedDirectory"]["size"] != len(shapes) * sizes["VecHeader"]["size"]:
        raise ValueError("directory sketch shape count differs from generated schema")
    original = header_costs(rows, 80, 2, 256, sizes)
    if original["page_slots"] != 20_968_456 or original["pages"] != 156_916:
        raise ValueError("per-file page model does not reproduce archived core capacity")
    candidates = []
    for first, limit in POLICIES:
        costs, active = page_costs(rows, shapes, first, limit, sizes)
        for strategy in STRATEGIES:
            directory = directory_costs(strategy, costs, active, sizes)
            for header_first, header_limit in [(2, 256), (1, 64), (1, 32)]:
                header = header_costs(rows, 24, header_first, header_limit, sizes)
                live = header["capacity"] + header["directory_live"] + costs["capacity_bound"] + directory["live"]
                requests = header["capacity"] + header["directory_requests"] + costs["capacity_bound"] + directory["requests"]
                syntax = header["capacity"] + header["directory_live"] + costs["capacity_syntax"] + directory["live"]
                candidates.append({"payload_policy": {"first": first, "maximum": limit},
                    "header_policy": {"first": header_first, "maximum": header_limit},
                    "directory_strategy": strategy, "live_accounted_bytes": live,
                    "requests_accounted_bytes": requests, "directory_superseded_requests": requests - live,
                    "remaining_of_880mb_before_unknowns": 880_000_000 - live,
                    "syntax_attributing_all_shared_directories_to_syntax": syntax,
                    "binding_payload_increment": costs["capacity_bound"] - costs["capacity_syntax"],
                    "payload_spare": costs["capacity_bound"] - costs["used_bound"],
                    "payloads": costs, "header": header, "directory": directory,
                    "allocation_calls_excluding_embedded_owner_root": header["pages"] + header["directory_allocations"]
                        + costs["payload_pages"] + directory["allocations_excluding_embedded_root"],
                    "feasibility": "unproved"})
    candidates.sort(key=lambda item: item["live_accounted_bytes"])
    ordinary = next(item for item in candidates if item["payload_policy"] == {"first": 2, "maximum": 256}
                    and item["header_policy"] == {"first": 2, "maximum": 256} and item["directory_strategy"] == "fixed_vec")
    payload_used = sum(total[name] * shapes[name]["bound_layout"]["size"] for name in total)
    syntax_used = sum(total[name] * shapes[name]["syntax_layout"]["size"] for name in total)
    return {"version": 1, "diagnostic_only": True, "outcome": "feasibility_unproved",
        "files": len(rows), "core_nodes": sum(total.values()), "observed_shapes": len(total),
        "generated_shapes": len(shapes), "active_file_shape_pairs": sum(len(row["core_shapes"]) for row in rows),
        "active_shapes_per_file": {"minimum": min(len(row["core_shapes"]) for row in rows),
            "median": median(len(row["core_shapes"]) for row in rows), "maximum": max(len(row["core_shapes"]) for row in rows)},
        "exact_weighted_used_bytes": {"syntax": syntax_used, "bound": payload_used, "binding_increment": payload_used - syntax_used},
        "core_shape_counts": dict(sorted(total.items())), "directory_layouts": sizes,
        "original_header_page_model_reproduction": original,
        "naive_existing_page_policy_with_fixed_shape_vectors": ordinary,
        "lowest_accounted_candidate": candidates[0], "candidates": candidates,
        "unknowns": ["Replacement payload pages/directories are projected policies, not actual allocated capacities or measured native requests.",
            "Full-range parent/edge/text escapes, runtime IDs, compatibility state, pooled-name metadata and owner roots beyond the charged directory fields remain unknown.",
            "Unused or checker-only deferred schema fields are still excluded as explicitly recorded by CP0; uncommon constructed payload eligibility needs its fallback.",
            "Allocator rounding/control data and the257.480MB baseline requested-live remainder are not solved by this model.",
            "Counters use the current40-byte page descriptor envelope; a different lifetime/accounting design requires a separate proof.",
            "A low byte count does not establish low CPU cost: optional directories add indirection, packed directories add tag/index routing, and smaller pages add allocations.",
            "This prices only syntax/binding and their directory growth; scanner/list/string/symbol/flow traffic must still fit the independent350MB traffic ceiling."]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--capture", type=Path, required=True)
    parser.add_argument("--build", type=Path, required=True)
    parser.add_argument("--build-sha", required=True)
    parser.add_argument("--output", type=Path, default=HERE / "layout-projection.json")
    parser.add_argument("--scratch", type=Path, default=ROOT / "target/s07-bis-directory-layout")
    args = parser.parse_args()
    capture_path, build_path = args.capture.resolve(), args.build.resolve()
    build = probe.validate_build(build_path, args.build_sha)
    capture = strict_json_loads((capture_path / "report.json").read_bytes())
    if (capture.get("status") != "complete" or capture.get("kind") != "owned_core_shapes"
            or capture["build_manifest_sha256"] != args.build_sha):
        raise ValueError("shape capture does not identify this completed immutable build")
    shape_path = capture_path / "core-shapes.ndjson"
    if probe.runner.digest(shape_path) != capture["summary"]["core_shapes_sha256"]:
        raise ValueError("shape capture bytes changed")
    probe.validate_shapes(shape_path, build["expected_work"])
    data = shape_path.read_bytes()
    rows = [strict_json_loads(line) for line in data.splitlines()]
    model_path = HERE.parent / "layout/baseline-model.json"
    model = strict_json_loads(model_path.read_bytes())
    if (build["source_fingerprint"]["files"]["crates/ts_ast/src/data_generated.rs"]
            != model["provenance"]["generated_ast_sha256"]):
        raise ValueError("compiled payload layouts belong to a different generated schema")
    sizes, compilation = compile_directory_sketch(args.scratch.resolve())
    result = project(rows, model, sizes)
    result["provenance"] = {"shape_capture_report_sha256": probe.runner.digest(capture_path / "report.json"),
        "core_shapes_sha256": probe.runner.digest(shape_path), "build_manifest_sha256": args.build_sha,
        "build_source_fingerprint": build["source_fingerprint"]["sha256"], "build_revision": build["revision"],
        "generated_layout_model_sha256": probe.runner.digest(model_path), "projection_script_sha256": probe.runner.digest(Path(__file__)),
        "loaded_input_sha256": build["expected_work"]["loaded_input_sha256"], "directory_compilation": compilation,
        "note": "Binary/source provenance comes from the immutable phase build, not the newer checkout census-launch fingerprint."}
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    (HERE / "core-shapes.ndjson.gz").write_bytes(gzip.compress(data, mtime=0))
    proof = {"capture": capture, "build_manifest": build,
             "raw_stdout": (capture_path / "sample-0-consuming.stdout").read_text(),
             "raw_stderr": (capture_path / "sample-0-consuming.stderr").read_text()}
    (HERE / "core-shapes-provenance.json.gz").write_bytes(gzip.compress(json.dumps(proof, sort_keys=True).encode(), mtime=0))
    print(json.dumps({key: result[key] for key in ("active_file_shape_pairs", "exact_weighted_used_bytes", "lowest_accounted_candidate")}, indent=2))


if __name__ == "__main__":
    main()
