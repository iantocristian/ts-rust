//! CP0 storage envelopes, not production arenas or evidence of access speed.
#![forbid(unsafe_code)]
#![allow(dead_code)]
use std::mem::{align_of, size_of};

const SHAPES: usize = 192;

// The existing census measures40 bytes per Page directory element: Vec's24
// bytes and16 bytes of counter bookkeeping. Keep that charge in this model.
struct Page<T> {
    values: Vec<T>,
    counter_bookkeeping: [usize; 2],
}

enum PackedPages {
    Words(Vec<Page<u32>>),
    Wide(Vec<Page<[u64; 8]>>),
}
enum OneOrMany<T> {
    One(Page<T>),
    Many(Vec<Page<T>>),
}
struct InlineFirst<T> {
    first: Page<T>,
    rest: Vec<Page<T>>,
}

struct FixedDirectory {
    entries: [Vec<Page<u32>>; SHAPES],
}
struct OptionalDirectory {
    entries: [Option<Box<Vec<Page<u32>>>>; SHAPES],
}
struct PackedDirectory {
    shape_to_entry: [u16; SHAPES],
    entries: Vec<PackedPages>,
}

fn main() {
    for (name, size, align) in [
        ("Page", size_of::<Page<u32>>(), align_of::<Page<u32>>()),
        ("VecHeader", size_of::<Vec<u32>>(), align_of::<Vec<u32>>()),
        (
            "OptionalPointer",
            size_of::<Option<Box<Vec<u32>>>>(),
            align_of::<Option<Box<Vec<u32>>>>(),
        ),
        (
            "PackedPages",
            size_of::<PackedPages>(),
            align_of::<PackedPages>(),
        ),
        (
            "OneOrMany",
            size_of::<OneOrMany<u32>>(),
            align_of::<OneOrMany<u32>>(),
        ),
        (
            "InlineFirst",
            size_of::<InlineFirst<u32>>(),
            align_of::<InlineFirst<u32>>(),
        ),
        (
            "FixedDirectory",
            size_of::<FixedDirectory>(),
            align_of::<FixedDirectory>(),
        ),
        (
            "OptionalDirectory",
            size_of::<OptionalDirectory>(),
            align_of::<OptionalDirectory>(),
        ),
        (
            "PackedDirectory",
            size_of::<PackedDirectory>(),
            align_of::<PackedDirectory>(),
        ),
    ] {
        println!("{name} {size} {align}");
    }
}
