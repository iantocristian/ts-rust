# Frozen CP1 list-copy generated-code inspection

Read-only inspection of the normal Mach-O arm64 benchmark artifacts, using
Apple LLVM 21.0.0 `nm` and `objdump`. No binary was built or executed. This
checks the generated routing and static stack frames; it does not measure
elapsed time, allocation, RSS, maximum recursion depth or stacker growth.

The control is the retained CP1 node-read candidate, manifest
`3a57976f667b9857891edbe9f76de5261c43480ac8c62d946b4545d9ee19d931`,
normal binary SHA256
`36c8eaf369846e811287be7da517555ca742e40e88dd2599adee31b3450278c5`.
The list-copy candidate manifest is
`b03b64ebf3faed4bb2245fa7b76db4289c3a1e510e796e86337c0782fb5f3578`,
normal binary SHA256
`35189166401e4dbc965da663961428bb9756081c5f937169d826bee7a55e00c6`.
Both binary hashes match their manifests and were checked again after
inspection. `receipt.json` records the exact command arrays, working directory,
return codes, tool versions, frozen source hashes and raw output hashes. All
16 recorded commands returned zero. The `*-containers.rs` files are copies of
the respective frozen sources, not the current checkout.

## Routing observed

The candidate's `for_each_syntax_node` specialization for `bind_each`, entry
`0x10012ab08`, contains an outer loop advancing by 16 at `0x10012ab90` and
computes a final partial chunk with a minimum against 16. In that outer loop it
calls `StorageView::aux` at `0x10012abf8`, `node_slice_read` at `0x10012ac74`,
and `NodeSliceRead::deref` at `0x10012aca0`. A range check precedes the copy.
It passes `count * 8` bytes to `_memcpy` at `0x10012acc4`, with destination
`sp + 0x30`; the Mach-O indirect-symbol table confirms the target
`0x1002027c0` is `_memcpy`. The 128-byte buffer is zero-initialized once on
helper entry by four paired vector stores at `0x10012ab2c..0x10012ab38`.

After copying, `0x10012acc8..0x10012acf0` contains the optional lazy Arc guard
release and slow-drop branch. The inner loop loads each copied ID from the
stack buffer at `0x10012ad24` and calls `bind_worker` at `0x10012ad14` on the
ordinary stack path. No slice resolution or copy occurs on that inner-loop
back edge; the next resolution occurs after advancing the outer chunk. Null
IDs are skipped by this specialization. This agrees with the lexical guard
scope in frozen `candidate-containers.rs:479`.

Functions-first remains two complete ordered passes. Its wrapper at
`0x10012ccc0` resolves the list descriptor through `syntax_slice` once and
calls the two chunk helpers at `0x10012ccec` and `0x10012ccf8`. These are normal
calls, not tail calls. The first helper resolves/dereferences/copies at
`0x10012c504`, `0x10012c52c`, `0x10012c54c`; the second does so at
`0x10012c998`, `0x10012c9c0`, `0x10012c9e0`. Both release the optional slice
guard before their inner loops. The helpers fetch each node and inspect its
current kind after loading the copied ID: the first calls `BindBuilder::node`
at `0x10012c5f0` and loads the direct-core kind at `0x10012c64c`; the second's
corresponding direct-core load is at `0x10012cae0`. The copied data is IDs,
not a snapshot of node kinds or flags.

In the control, functions-first calls `syntax_node` separately per element
on both passes (`0x10012c328`, `0x10012c46c`). That helper resolves the auxiliary
storage, builds the checked slice, dereferences it and indexes one ID
(`0x10011fd80`, `0x10011fdec`, `0x10011fe04`, `0x10011fe10`). The control's
standalone `bind_node_list` likewise calls `syntax_node` per element at
`0x100133d80`. The candidate still contains `syntax_node` for other paths;
this is not a claim that every binder list access has changed.

## Static stack frames

Own frames include saved registers. These are observed prologue/epilogue
sizes, not inferred from the Rust source's 128-byte buffer.

| Function | Control own frame | Candidate own frame |
| --- | ---: | ---: |
| `syntax_node` | 224 B | 224 B |
| `bind_each_child` | 688 B | 736 B |
| functions-first wrapper/body | 176 B | 48 B |
| functions-first chunk helper, either pass | absent | 448 B |
| `bind_each` chunk helper | absent | 464 B |
| `ChildVisitor::visit_node_slice` control body | 272 B | inlined in inspected child caller |
| standalone `bind_node_list` | 176 B | no standalone symbol identified |

For functions-first while an ordinary child `bind_worker` call is active,
the control retains the 176-byte caller frame. The candidate retains its
48-byte wrapper plus one 448-byte helper, totaling 496 bytes: **320 bytes
more in this identified caller chain**. The two helpers run sequentially,
so their frames must not be added together. The control's temporary
224-byte `syntax_node` frame has already returned when binding the child.

For the identified `bind_each_child` slice path, the control calls
`ChildVisitor::visit_node_slice` at `0x100122424`; that 272-byte visitor frame
remains while it binds a child. Its retained caller subtotal is
688 + 272 = 960 bytes. The candidate inlines that visitor work and calls the
464-byte chunk helper at `0x100122370`, giving 736 + 464 = 1,200 bytes:
**240 bytes more in this identified caller chain**. The direct-single-node
branch instead has the 48-byte own-frame increase. These subtotals exclude
`bind_worker`, its descendants, temporary resolution callees, unwind paths
and stacker slow paths. They are not a whole-program maximum-stack result.

## Scope and reproduction

`nm --defined-only --numeric-sort <binary>` supplies the raw symbol names.
Each chosen symbol is inspected with
`objdump --disassemble --disassemble-symbols=<raw-symbol> <binary>`.
`objdump --macho --indirect-symbols <candidate>` identifies the copy stub.
The complete commands and their unedited stdout/stderr are retained here.
The inspection covers the named normal-arm64 functions only; other inlined
callers, other architectures and the allocation-instrumented artifact were
not inspected. Source semantics establish the borrow scope; disassembly
confirms the visible copy/drop/call placement, not a separate lifetime proof.
